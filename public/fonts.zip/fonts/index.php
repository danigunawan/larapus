<?php 

header("location: ../index.php");

 ?>